import torch


IS_ROCM = torch.version.hip is not None
