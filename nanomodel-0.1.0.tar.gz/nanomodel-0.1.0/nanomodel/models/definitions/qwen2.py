from __future__ import annotations

from .llama import LlamaNanoModel


class Qwen2NanoModel(LlamaNanoModel):
    pass
