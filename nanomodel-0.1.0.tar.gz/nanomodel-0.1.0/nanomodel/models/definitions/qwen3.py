from . import LlamaNanoModel

class Qwen3NanoModel(LlamaNanoModel):
    pass