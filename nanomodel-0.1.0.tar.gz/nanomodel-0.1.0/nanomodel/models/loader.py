from __future__ import annotations

import operator
import os
import time
from importlib.metadata import PackageNotFoundError, version
from typing import Dict, Iterable, Optional, Union

import accelerate
import torch
import transformers

# TODO: Hugging Face or Modelscope
from huggingface_hub import snapshot_download # (Auto download model when no local)

from packaging.version import InvalidVersion, Version
from transformers import AutoConfig, AutoTokenizer, PretrainedConfig
from transformers.modeling_utils import no_init_weights
from transformers.utils import is_flash_attn_2_available # Support flash_attn ?
from transformers.utils.generic import ContextManagers

from ..quantization import QuantizeConfig
from ..quantization.config import KERNEL, METHOD
from ..utils.backend import BACKEND
from ..utils.importer import auto_select_device, normalize_device_device_map, select_quant_linear
from ..utils.logger import setup_logger
from ..utils.marlin import _validate_marlin_device_support
from ..utils.model import (
    auto_dtype,
    find_config_seq_len,
    find_modules,
    get_checkpoints,
    get_module_by_name_prefix,
    gptqmodel_post_init,
    load_checkpoint_in_model_then_tie_weights,
    make_quant,
    simple_dispatch_model,
)
from ._const import DEVICE, normalize_device

log = setup_logger()

ATTN_IMPLEMENTATION = "attn_implementation"


def parse_version_string(version_str: str) -> Version:
    """Parse a version string into a packaging.Version, raising on invalid inputs."""
    try:
        return Version(version_str)
    except InvalidVersion as exc:
        raise ValueError(f"Invalid version format: {version_str}") from exc


def parse_requirement(req: str) -> tuple[str, str, str]:
    """Split a version requirement (e.g. 'torch>=2.2') into (package, operator, version)."""
    for op in (">=", "<=", ">", "<", "=="):
        if op in req:
            pkg, version_required = req.split(op, 1)
            return pkg.strip(), op, version_required.strip()
    raise ValueError(f"Unsupported version constraint in: {req}")


_OPERATORS = {
    ">": operator.gt,
    ">=": operator.ge,
    "<": operator.lt,
    "<=": operator.le,
    "==": operator.eq,
}


def compare_versions(installed_version: str, required_version: str, operand: str) -> bool:
    """Return True when the installed version satisfies the operand constraint."""
    installed = parse_version_string(installed_version)
    required = parse_version_string(required_version)
    try:
        comparator = _OPERATORS[operand]
    except KeyError as exc:
        raise ValueError(f"Unsupported operator: {operand}") from exc
    return comparator(installed, required)


def check_versions(model_class, requirements: Optional[Iterable[str]]):
    """Ensure optional package requirements declared by model loaders are satisfied."""
    if not requirements:
        return
    for req in requirements:
        pkg, operand, version_required = parse_requirement(req)
        try:
            installed_version = version(pkg)
        except PackageNotFoundError as exc:
            raise ValueError(f"{model_class} requires version {req}, but {pkg} is not installed.") from exc

        if not compare_versions(installed_version, version_required, operand):
            raise ValueError(
                f"{model_class} requires version {req}, but installed {pkg} version is {installed_version}."
            )


def get_model_local_path(pretrained_model_id_or_path: str, **kwargs) -> str:
    """
    Resolve a pretrained identifier into a local path.

    - Existing directories are returned unchanged (normalized).
    - Remote references trigger a snapshot download with unsupported kwargs stripped.
    """
    if os.path.isdir(pretrained_model_id_or_path):
        return os.path.normpath(pretrained_model_id_or_path)

    filtered_kwargs = {
        key: value
        for key, value in kwargs.items()
        if key not in {"attn_implementation", "use_flash_attention_2"}
    }
    return snapshot_download(pretrained_model_id_or_path, **filtered_kwargs)


def _disable_default_weight_initializers() -> None:
    """Skip expensive default torch initializers when loading large checkpoints."""

    def _skip(*_args, **_kwargs):
        return None

    torch.nn.init.kaiming_uniform_ = _skip
    torch.nn.init.uniform_ = _skip
    torch.nn.init.normal_ = _skip


def _assign_model_seqlen(model: torch.nn.Module, fallback: int = 4096) -> None:
    """Attach `model.seqlen` using config metadata or a conservative fallback."""
    model_config = model.config.to_dict()
    seq_len_keys = ["max_position_embeddings", "seq_length", "n_positions", "multimodal_max_length"]
    config_seq_len = find_config_seq_len(model_config, seq_len_keys)
    if config_seq_len is not None:
        model.seqlen = config_seq_len
    else:
        log.warn("Model: can't determine sequence length from model config; using fallback=%s.", fallback)
        model.seqlen = fallback


def ModelLoader(cls):
    """Decorator that injects NanoModel-specific loading helpers into transformer loaders."""
    @classmethod
    def from_pretrained(
        cls,
        pretrained_model_id_or_path: str,
        quantize_config: QuantizeConfig,
        trust_remote_code: bool = False,
        dtype: Union[str, torch.dtype] = "auto",
        device_map: Optional[Union[str, Dict[str, Union[int, str]]]] = None,
        device: Optional[Union[str, int]] = None,
        **model_init_kwargs,
    ):
        """Load an unquantized reference model prior to running offline quantization."""
        import torch._dynamo

        # Quantization flow mutates modules; guard against Dynamo capturing graphs.
        torch._dynamo.disable()

        load_start = time.perf_counter()

        if not isinstance(quantize_config, QuantizeConfig):
            raise AttributeError("`quantize_config` must be passed and be an instance of QuantizeConfig.")

        quantize_config.calculate_bits_per_weight()

        # Non-quantized weights are staged on CPU regardless of caller preference.
        if quantize_config.device is not None and (device is not None or device_map is not None):
            raise AttributeError(
                "Passing device and device_map is not allowed when QuantizeConfig.device is set. "
                "Set QuantizeConfig.device to control quantization placement."
            )

        if quantize_config.act_order not in cls.supports_act_order:
            raise ValueError(
                f"{cls} only supports act_order={cls.supports_act_order}, "
                f"but quantize_config.act_order is {quantize_config.act_order}."
            )

        if cls.require_trust_remote_code and not trust_remote_code:
            raise ValueError(
                f"{pretrained_model_id_or_path} requires trust_remote_code=True. "
                "Please set trust_remote_code=True to load this model."
            )

        check_versions(cls, cls.require_pkgs_version)

        model_local_path = get_model_local_path(pretrained_model_id_or_path, **model_init_kwargs)

        _disable_default_weight_initializers()

        model_init_kwargs["trust_remote_code"] = trust_remote_code
        config = AutoConfig.from_pretrained(model_local_path, **model_init_kwargs)

        requested_attn_impl = model_init_kwargs.get("attn_implementation")
        if requested_attn_impl and requested_attn_impl != "auto":
            log.info("Loader: overriding attn_implementation in config to `%s`", requested_attn_impl)
            config._attn_implementation = requested_attn_impl

        # Ensure quantization runs on an explicit device.
        if quantize_config.device is None:
            quantize_config.device = auto_select_device(None, None)
        else:
            quantize_config.device = normalize_device(quantize_config.device)

        if cls.require_dtype:
            dtype = cls.require_dtype

        if dtype is None or dtype == "auto" or not isinstance(dtype, torch.dtype):
            # Non-quantized modules should retain their native dtype for calibration.
            dtype = auto_dtype(config=config, device=quantize_config.device, quant_inference=False)

        if isinstance(dtype, torch.dtype) and getattr(config, "torch_dtype", None) != dtype:
            # Align config metadata with the dtype we will materialize weights in.
            config.torch_dtype = dtype

        # Non-quantized models are always materialized on CPU.
        model_init_kwargs["device_map"] = {"": "cpu"}
        model_init_kwargs["dtype"] = dtype
        model_init_kwargs["_fast_init"] = cls.require_fast_init

        cls.before_model_load(cls, load_quantized_model=False)
        from ..utils.hf import build_shell_model

        # XIELU activation allocates buffers during init; disable offload to avoid missing tensors.
        if getattr(config, "hidden_act", None) == "xielu":
            quantize_config.offload_to_disk = False

        if quantize_config.offload_to_disk:
            # Build a meta-device shell for quantization-aware recollection.
            model = build_shell_model(cls.loader, config=config, **model_init_kwargs)
            model._model_init_kwargs = model_init_kwargs

            turtle_spinner = log.spinner(title="Turtle model loading...", interval=0.1)
            try:
                turtle_model = cls.loader.from_pretrained(
                    model_local_path,
                    config=config,
                    low_cpu_mem_usage=True,
                    **model_init_kwargs,
                )
            finally:
                turtle_spinner.close()

            turtle_model._model_init_kwargs = model_init_kwargs
        else:
            log.info("Loader: loading model directly to CPU without turtle stage.")
            model = cls.loader.from_pretrained(model_local_path, config=config, **model_init_kwargs)
            model._model_init_kwargs = model_init_kwargs
            turtle_model = None

        _assign_model_seqlen(model)

        model.eval()
        if turtle_model is not None:
            turtle_model.eval()

        tokenizer = AutoTokenizer.from_pretrained(pretrained_model_id_or_path, trust_remote_code=trust_remote_code)

        instance = cls(
            model,
            turtle_model=turtle_model,
            quantized=False,
            quantize_config=quantize_config,
            tokenizer=tokenizer,
            trust_remote_code=trust_remote_code,
            model_local_path=model_local_path,
        )

        timer = getattr(instance, "quant_region_timer", None)
        if timer is not None:
            source_label = instance.model_local_path or str(pretrained_model_id_or_path)
            timer.record("model_load", time.perf_counter() - load_start, source=source_label)

        return instance

    cls.from_pretrained = from_pretrained

    @classmethod
    def from_quantized(
        cls,
        model_id_or_path: Optional[str],
        device_map: Optional[Union[str, Dict[str, Union[int, str]]]] = None,
        device: Optional[Union[str, int]] = None,
        backend: Union[str, BACKEND] = BACKEND.AUTO,
        dtype: Union[str, torch.dtype] = "auto",
        trust_remote_code: bool = False,
        max_memory: Optional[dict] = None,
        **kwargs,
    ):
        """Load a quantized checkpoint produced by NanoModel for inference."""
        import torch._dynamo

        # Post-quantization models can safely re-enable Dynamo graph capture.
        torch._dynamo.reset()

        device = normalize_device_device_map(device, device_map)

        if isinstance(backend, str):
            try:
                backend = BACKEND(backend)
            except ValueError as exc:
                raise ValueError(f"Unknown backend {backend!r}.") from exc
        device = auto_select_device(device, backend)

        if backend == BACKEND.VLLM:
            import os

            # Hint VLLM to use the faster FlashInfer backend when available.
            os.environ["VLLM_ATTENTION_BACKEND"] = "FLASHINFER"

        if backend == BACKEND.TRITON:
            from ..nn_modules.qlinear.tritonv2 import TRITON_AVAILABLE, TRITON_INSTALL_HINT
            if not TRITON_AVAILABLE:
                raise ValueError(TRITON_INSTALL_HINT)

        # Load quantized model from local disk or remote hub snapshot.
        if cls.require_trust_remote_code and not trust_remote_code:
            raise ValueError(
                f"{model_id_or_path} requires trust_remote_code=True. Please set trust_remote_code=True to load this model."
            )

        check_versions(cls, cls.require_pkgs_version)

        model_local_path = get_model_local_path(model_id_or_path, **kwargs)

        # Parameters related to loading from Hugging Face Hub
        cache_dir = kwargs.pop("cache_dir", None)
        force_download = kwargs.pop("force_download", False)
        resume_download = kwargs.pop("resume_download", False)
        proxies = kwargs.pop("proxies", None)
        local_files_only = kwargs.pop("local_files_only", False)
        use_auth_token = kwargs.pop("use_auth_token", None)
        revision = kwargs.pop("revision", None)
        subfolder = kwargs.pop("subfolder", "")
        commit_hash = kwargs.pop("_commit_hash", None)
        attn_implementation = kwargs.pop("attn_implementation", None)

        cached_file_kwargs = {
            "cache_dir": cache_dir,
            "force_download": force_download,
            "proxies": proxies,
            "resume_download": resume_download,
            "local_files_only": local_files_only,
            "use_auth_token": use_auth_token,
            "revision": revision,
            "subfolder": subfolder,
            "_raise_exceptions_for_missing_entries": False,
            "_commit_hash": commit_hash,
            "attn_implementation": attn_implementation,
        }

        # == step1: prepare configs and file names == #
        config: PretrainedConfig = AutoConfig.from_pretrained(
            model_local_path,
            trust_remote_code=trust_remote_code,
            **cached_file_kwargs,
        )

        if cls.require_dtype:
            dtype = cls.require_dtype

        if dtype is None or dtype == "auto" or not isinstance(dtype, torch.dtype) :
            # TODO FIX ME for `dynamic`, non-quantized modules should be in native type
            dtype = auto_dtype(config=config, device=device, quant_inference=True)

        if isinstance(dtype, torch.dtype) and getattr(config, "torch_dtype", None) != dtype:
            # Ensure flash attention kernels see an explicit dtype instead of relying on defaults.
            config.torch_dtype = dtype

        # Load quantization metadata stored alongside the checkpoint.
        qcfg = QuantizeConfig.from_pretrained(model_local_path, **cached_file_kwargs, **kwargs)

        if qcfg.quant_method == METHOD.AWQ and qcfg.kernel in [KERNEL.GEMV_FAST]:
            # GEMV_FAST only supports torch.float16
            log.info("Loading Quantized Model: Auto fix `dtype` to `torch.float16`")
            dtype = torch.float16

        qcfg.calculate_bits_per_weight()
        tokenizer = AutoTokenizer.from_pretrained(model_id_or_path, trust_remote_code=trust_remote_code)
        if backend == BACKEND.VLLM or backend == BACKEND.SGLANG:
            # Delegate inference to external runtimes; NanoModel wrapper keeps tokenizer/qcfg consistent.
            if backend == BACKEND.VLLM:
                if qcfg.kernel != KERNEL.GPTQ and qcfg.kernel != KERNEL.GEMM:
                    raise ValueError(f"{backend} backend only supports FORMAT.GPTQ or FORMAT.GEMM: actual = {qcfg.kernel}")
            elif backend == BACKEND.SGLANG:
                if qcfg.kernel != KERNEL.GPTQ:
                    raise ValueError(f"{backend} backend only supports FORMAT.GPTQ: actual = {qcfg.kernel}")

            if backend == BACKEND.VLLM:
                from ..utils.vllm import load_model_by_vllm, vllm_generate

                model = load_model_by_vllm(
                    model=model_local_path,
                    trust_remote_code=trust_remote_code,
                    **kwargs,
                )

                model.config = model.llm_engine.model_config
                model.device = model.llm_engine.vllm_config.device_config.device

                cls.generate = lambda self, **kwargs: vllm_generate(self.model, **kwargs)

            elif backend == BACKEND.SGLANG:
                from ..utils.sglang import load_model_by_sglang, sglang_generate

                model, hf_config = load_model_by_sglang(
                    model=model_local_path,
                    trust_remote_code=trust_remote_code,
                    dtype=torch.float16,
                    **kwargs,
                )
                model.config = hf_config
                cls.generate = lambda self, **kwargs: sglang_generate(self.model, **kwargs)
            return cls(
                model,
                quantized=True,
                quantize_config=qcfg,
                tokenizer=tokenizer,
                qlinear_kernel=None,
                load_quantized_model=True,
                trust_remote_code=trust_remote_code,
                model_local_path=model_local_path,
            )

        if qcfg.kernel == KERNEL.MARLIN:
            # format marlin requires marlin kernel
            if backend not in [BACKEND.MARLIN, BACKEND.MARLIN_FP16] and backend != BACKEND.AUTO:
                raise TypeError(f"FORMAT.MARLIN requires BACKEND.AUTO or BACKEND.MARLIN: actual = `{backend}`.")
            backend = BACKEND.MARLIN

        # marlin_compatible = False if backend == BACKEND.IPEX else _validate_marlin_device_support()
        # check for marlin compat for cuda device only
        # if backend not in [BACKEND.MARLIN, BACKEND.MARLIN_FP16] and device == DEVICE.CUDA:
        #     unsupported = _validate_marlin_compatibility(qcfg)
        #     if unsupported is None and marlin_compatible:
        #         logger.info(
        #             "Hint: Model is compatible with the Marlin kernel. Marlin is optimized for batched inference on Nvidia GPU: `model = GPTQModel.load(..., backend=BACKEND.MARLIN)`."
        #         )

        possible_model_basenames = [
            f"gptq_model-{qcfg.bits}bit-{qcfg.group_size}g",
            "model",
        ]

        extensions = [".safetensors"]

        model_local_path = str(model_local_path)

        # Retrieve (and if necessary download) the quantized checkpoint(s).
        is_sharded, resolved_archive_file, true_model_basename = get_checkpoints(
            model_id_or_path=model_local_path,
            extensions=extensions,
            possible_model_basenames=possible_model_basenames,
            **cached_file_kwargs,
        )

        # bin files have security issues: disable loading by default
        if ".bin" in resolved_archive_file:
            raise ValueError(
                "Loading of .bin files are not allowed due to safety. Please convert your model to safetensor or pytorch format."
            )

        qcfg.runtime_format = qcfg.kernel

        model_save_name = resolved_archive_file  # In case a model is sharded, this would be `model.safetensors.index.json` which may later break.

        # == step2: convert model to gptq-model (replace Linear with QuantLinear) == #
        _disable_default_weight_initializers()
        transformers.modeling_utils._init_weights = False

        init_contexts = [no_init_weights()]

        layer_type = ""
        with (ContextManagers(init_contexts)):
            cls.before_model_load(cls, load_quantized_model=True)

            if config.architectures:
                model_class = getattr(transformers, config.architectures[0], None)
                if model_class is not None and hasattr(model_class, "_supports_flash_attn_2"):
                    supports_flash_attn = model_class._supports_flash_attn_2
                else:
                    supports_flash_attn = None
            else:
                supports_flash_attn = None

            args = {}
            if supports_flash_attn and device in [DEVICE.CUDA]:
                if ATTN_IMPLEMENTATION in kwargs:
                    args[ATTN_IMPLEMENTATION] = kwargs.pop(ATTN_IMPLEMENTATION, None)
                elif is_flash_attn_2_available():
                    args = {ATTN_IMPLEMENTATION: "flash_attention_2"}
                    log.info("Loader: Auto enabling flash attention2")

            model = cls.loader.from_config(config, trust_remote_code=trust_remote_code, dtype=dtype, **args)

            model.checkpoint_file_name = model_save_name

            # Get the first layer to determine layer type
            layers, _ = get_module_by_name_prefix(model, cls.extract_layers_node())

            if layers:
                layer_type = type(layers[0]).__name__

            modules = find_modules(model)
            ignore_modules = [cls.lm_head] + cls.get_base_modules(model)
            layer_prefixes = tuple(cls.extract_layers_node())
            simple_layer_suffixes = tuple(
                suffix for group in cls.simple_layer_modules(config, qcfg) for suffix in group
            )

            for name in list(modules.keys()):
                if qcfg.lm_head and name == cls.lm_head:
                    # Allow loading of quantized lm_head.
                    continue

                eligible_prefix = any(name.startswith(prefix) for prefix in layer_prefixes)
                excluded_module = any(name.startswith(ignore_module) for ignore_module in ignore_modules)
                eligible_suffix = any(name.endswith(suffix) for suffix in simple_layer_suffixes)

                if not eligible_prefix or excluded_module or not eligible_suffix:
                    if name != cls.lm_head:
                        log.info("Loader: layer %s is skipped from quantization.", name)
                    del modules[name]

            preload_qlinear_kernel = make_quant(
                model,
                qcfg=qcfg,
                quant_result=modules,
                backend=backend,
                lm_head_name=cls.lm_head,
                device=device,
            )

        if isinstance(device_map, str) and device_map not in {"auto", "balanced", "balanced_low_0", "sequential"}:
            raise ValueError(
                "If passing a string for `device_map`, please choose 'auto', 'balanced', 'balanced_low_0' or "
                "'sequential'."
            )

        computed_device_map = device_map
        no_split_modules = [layer_type] if layer_type else []

        if isinstance(computed_device_map, dict):
            max_memory = None
        else:
            if device is None and not computed_device_map and not max_memory:
                computed_device_map = "auto"

            if device is not None and not max_memory and not computed_device_map:
                torch_device = torch.device(device)
                if torch_device.type in {"cuda", "xpu"} and torch_device.index is not None:
                    computed_device_map = {"": torch_device.index}
                else:
                    computed_device_map = {"": torch_device.type}

            if not isinstance(computed_device_map, dict) and computed_device_map != "sequential":
                max_memory = accelerate.utils.get_balanced_memory(
                    model=model,
                    max_memory=max_memory,
                    no_split_module_classes=no_split_modules,
                    low_zero=(computed_device_map == "balanced_low_0"),
                )

        if not isinstance(computed_device_map, dict):
            computed_device_map = accelerate.infer_auto_device_map(
                model,
                max_memory=max_memory,
                no_split_module_classes=no_split_modules,
            )

        device_map = computed_device_map

        load_checkpoint_in_model = True
        if qcfg.kernel in [KERNEL.GPTQ, KERNEL.GEMM]:
            load_checkpoint_in_model_then_tie_weights(
                model,
                dtype=dtype,
                # This is very hacky but works due to https://github.com/huggingface/accelerate/blob/bd72a5f1a80d5146554458823f8aeda0a9db5297/src/accelerate/utils/modeling.py#L292
                checkpoint=model_save_name,
                device_map=device_map,
                offload_state_dict=True,
                offload_buffers=True,
            )

            load_checkpoint_in_model = False
        if backend in [BACKEND.MARLIN, BACKEND.MARLIN_FP16] and (qcfg.kernel == KERNEL.MARLIN):
            if is_sharded:
                raise ValueError(
                    "Format: The loading of sharded checkpoints with Marlin is currently not supported."
                )
            if not _validate_marlin_device_support():
                raise ValueError(
                    f'Kernel: Marlin kernel does not support this gpu with compute capability of `{torch.cuda.get_device_capability()}`. Please do not use `back=BACKEND.MARLIN`.'
                )

            # Validate the model can run in Marlin.
            if dtype != torch.float16:
                raise ValueError("Marlin kernel requires dtype=torch.float16.")
 

        # If we use marlin or bitblas to load the quantized model, the model is already a converted model,
        # and we no longer need to call load_checkpoint_in_model()
        if load_checkpoint_in_model and backend not in [BACKEND.MARLIN, BACKEND.MARLIN_FP16]:
            load_checkpoint_in_model_then_tie_weights(
                model,
                dtype=dtype,
                # This is very hacky but works due to https://github.com/huggingface/accelerate/blob/bd72a5f1a80d5146554458823f8aeda0a9db5297/src/accelerate/utils/modeling.py#L292
                checkpoint=model_save_name,
                device_map=device_map,
                # offload_state_dict=True,
                # offload_buffers=True,
            )

        # TODO: Why are we using this custom function and not dispatch_model?
        model = simple_dispatch_model(model, device_map)

        qlinear_kernel = select_quant_linear(
            bits=qcfg.bits,
            dynamic=qcfg.dynamic,
            group_size=qcfg.group_size,
            act_order=qcfg.act_order,
            sym=qcfg.sym,
            backend=backend,
            kernel=qcfg.kernel,
            quant_method=qcfg.quant_method,
            device=device,
            pack_dtype=qcfg.pack_dtype,
        )

        # == step4: set seqlen == #
        _assign_model_seqlen(model)

        # Any post-initialization that require device information, for example buffers initialization on device.
        model = gptqmodel_post_init(model, use_act_order=qcfg.act_order, quantize_config=qcfg)

        # TODO: eval()
        # model.eval()

        # TODO: MLX FOR MAC

        return cls(
            model,
            quantized=True,
            quantize_config=qcfg,
            tokenizer=tokenizer,
            qlinear_kernel=qlinear_kernel,
            load_quantized_model=True,
            trust_remote_code=trust_remote_code,
            model_local_path=model_local_path,
        )

    cls.from_quantized = from_quantized

    return cls
